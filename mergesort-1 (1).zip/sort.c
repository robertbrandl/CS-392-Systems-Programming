/*Robert Brandl
I pledge my honor that I have abided by the Stevens Honor System.*/
#include "mergesort.h"
#include <stdio.h>
#include <getopt.h>
#include <string.h>
#include <stdlib.h>

void usage(){ //usage message to be printed
    printf("Usage: ./sort [-i|-d] filename\n-i: Specifies the file contains ints.\n-d: Specifies the file contains doubles.\nfilename: The file to sort.\n");
}

int main(int argc, char *argv[]){
    size_t opt;
    FILE* fp;//creates the function pointer
    if (argc == 1){//when only one argument (no flags or files), print usage and exit
        usage();
        exit(EXIT_FAILURE);
    }
    size_t validflags = 0;//keeps track of valid flag repetitions to prep for errors
    size_t choice;//set to 0 if integer flag chosen, set to 1 for doubles
    while ((opt = getopt(argc, argv, ":id")) != -1)//uses getopt to check for invalid arguments and tracks repetitions of valid flags, sets choice
    {
        switch (opt){
            case 'i':
                validflags++;
                choice = 0;
                break;
            case 'd':
                validflags++;
                choice = 1;
                break;
            case '?':
                printf("Error: unknown option '-%c' received.\n", optopt);//when the argument is invalid, or valid followed by invalid, throw error
                usage();
                exit(EXIT_FAILURE);
        }
    }
    if (validflags > 1){//if too many flags but all valid
        printf("Error: Too many flags specified.\n");
        exit(EXIT_FAILURE);
    }
    if (argc > 3){//when there is one flag but too many files
        printf("Error: Too many files specified.\n");
        exit(EXIT_FAILURE);
    }
    if (argc == 2){//when there is one flag but no input file
        printf("Error: No input file specified.\n");
        exit(EXIT_FAILURE);
    }
    if ((fp = fopen(argv[2], "r")) == NULL){//checks if the file given can be opened
        fprintf(stderr, "Error: Cannot open '%s'. No such file or directory.\n", argv[2]); 
        exit(EXIT_FAILURE);
    }
    if (choice == 0){//if the user chooses a file of integers
        int* arr = (int*) malloc(1024 * sizeof(int));//uses malloc to create an array with max size of 1024
        size_t ind = 0;//creates an index variable to read file
        while (fscanf(fp, "%d", &arr[ind]) == 1) {//reads through the file and adds to the array
            ind++;
        }
        int newarr[ind];//creates a new array of the proper size, based on the final value of ind
        for (size_t i = 0; i < ind; i++){//copies the arr to the newarr
            newarr[i] = arr[i];
        }
        free(arr);//frees the array to prevent mem leaks
        fclose(fp);//closes the file
        mergesort((void*) &newarr, ind, sizeof(int), &int_cmp);//makes a call to mergesort with the new array, the ind for the length, the size for an integer, and the proper comparison function
        for (size_t i = 0; i < ind; i++){//prints out the new values, sorted
            printf ("%d\n", newarr[i]);
        }
    }
    if (choice == 1){//if the user chooses a file of doubles
        double* arr = (double*) malloc(1024 * sizeof(double));//uses malloc to create an array with max size of 1024
        size_t ind = 0;//creates an index variable to read file
        while (fscanf(fp, "%lf", &arr[ind]) == 1) {//reads through the file and adds to the array
            ind++;
        }
        double newarr[ind];//creates a new array of the proper size, based on the final value of ind
        for (size_t i = 0; i < ind; i++){//copies the arr to the newarr
            newarr[i] = arr[i];
        }
        free(arr);//frees the array to prevent mem leaks
        fclose(fp);//closes the file
        mergesort((void*) &newarr, ind, sizeof(double), &dbl_cmp);//makes a call to mergesort with the new array, the ind for the length, the size for a double, and the proper comparison function
        for (size_t i = 0; i < ind; i++){//prints out the new values, sorted
            printf ("%lf\n", newarr[i]);
        }
    }
    return EXIT_SUCCESS;
}
