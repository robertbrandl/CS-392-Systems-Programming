/*Robert Brandl
I pledge my honor that I have abided by the Stevens Honor System.*/
#include "mergesort.h"
#include <stdlib.h>
#include <stdio.h>
/* Functions to compare a and b using different variable casting */
int int_cmp(const void* a, const void* b){
    int* x = (int*) a;
    int* y = (int*) b;
    if (*x == *y){
        return 0;
    }
    else if (*x > *y){
        return 1;
    }
    else{
        return -1;
    }
}
int dbl_cmp(const void* a, const void* b){
    double* x = (double*) a;
    double* y = (double*) b;
    if (*x == *y){
        return 0;
    }
    else if (*x > *y){
        return 1;
    }
    else{
        return -1;
    }
}

void merge(void* arr, size_t l, size_t m, size_t r, size_t elem_sz, int (*comp)(const void*, const void*))//performs the main work of mergesort
{
    size_t n1 = m - l + 1;
    size_t n2 = r - m;
    /* create temp arrays using malloc since the size changes each iteration, and uses the size of the element to allocate enough space*/
    void* L = (void*) malloc(n1 * elem_sz);
    void* R = (void*) malloc(n2 * elem_sz);
    /* Copy data to temp arrays L[] and R[], accesses elements by casting the arrays to either int or double pointer based on the element size and dereferencing using [] notation */
    for (size_t i = 0; i < n1; i++){
        if (elem_sz == 4){
            (((int*)L)[i]) = (((int*)arr)[l+i]);
        }
        else{
            (((double*)L)[i]) = (((double*)arr)[l+i]);
        }
    }
    for (size_t j = 0; j < n2; j++){
        if (elem_sz == 4){
            (((int*)R)[j]) = (((int*)arr)[m + 1 + j]);
        }
        else{
            (((double*)R)[j]) = (((double*)arr)[m + 1 + j]);
        }
    }
    /* Merge the temp arrays back into arr[l..r], making use of the comparison functions and similar casting and dereferencing as done above*/
    size_t i = 0; // Index of first subarray
    size_t j = 0; // Index of second subarray
    size_t k = l; // Index of merged subarray
    while (i < n1 && j < n2) {
        if (elem_sz == 4){
               int valL = (((int*)L)[i]);
               int valR = (((int*)R)[j]);
		if (comp((void*)&valL,(void*)&valR) == 0 || comp((void*)&valL,(void*)&valR) == -1) {//uses the appropriate comparison function sent to it
		    (((int*)arr)[k]) = valL;
		    i++;
		}
		else {
		    (((int*)arr)[k]) = valR;
		    j++;
		}
		k++;
        }
        else{
               double valL = (((double*)L)[i]);
               double valR = (((double*)R)[j]);
		if (comp((void*)&valL,(void*)&valR) == 0 || comp((void*)&valL,(void*)&valR) == -1) {//uses the appropriate comparison function sent to it
		    (((double*)arr)[k]) = valL;
		    i++;
		}
		else {
		    (((double*)arr)[k]) = valR;
		    j++;
		}
		k++;
        }
    }
    /* Copy the remaining elements of L[] into the final array*/
    while (i < n1) {
        if (elem_sz == 4){
            int valL = (((int*)L)[i]);
            (((int*)arr)[k]) = valL;
        }
        else{
            double valL = (((double*)L)[i]);
            (((double*)arr)[k]) = valL;
        }
        i++;
        k++;
    }
    /* Copy the remaining elements of R[] into the final array*/
    while (j < n2) {
        if (elem_sz == 4){
            int valL = (((int*)R)[j]);
            (((int*)arr)[k]) = valL;
        }
        else{
            double valL = (((double*)R)[j]);
            (((double*)arr)[k]) = valL;
        }
        j++;
        k++;
    }
    free(L);//frees the malloc arrays created at the start to prevent mem leaks
    free(R);
}
void mergeSorter(void*  arr, size_t l, size_t r, size_t elem_sz, int (*comp)(const void*, const void*))
{
    if (l < r) {
        int m = l + (r - l) / 2;//computes the middle split point for the current array
        // Sort first and second halves recursively
        mergeSorter(arr, l, m, elem_sz, comp);
        mergeSorter(arr, m + 1, r, elem_sz, comp);
        merge(arr, l, m, r, elem_sz, comp);//recombines the two sorted halves
    }
}
/* Main sorting algorithm you need to implement - credit: geeksforgeeks mergesort code (modified based on the void* arrays) */
void mergesort(void*  array, size_t len, size_t elem_sz, int (*comp)(const void*, const void*)){
    mergeSorter(array, 0, len-1, elem_sz, comp);//calls helper function which takes in more arguments

}
