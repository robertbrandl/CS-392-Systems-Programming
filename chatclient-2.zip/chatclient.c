/*Robert Brandl
I pledge my honor that I have abided by the Stevens Honor System. */
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include "util.h"

int client_socket = -1;//fd for the client socket
char username[MAX_NAME_LEN + 1];//string for client username
char inbuf[BUFLEN + 1];//string for input messages
char outbuf[MAX_MSG_LEN + 1];//string for output messages

int handle_stdin() {//handles the client providing user input
	int message = get_string(outbuf, MAX_MSG_LEN +1);//calls the getstring helper function to take in user input
	if (message == TOO_LONG){//if the input is too long, print message
		printf("Sorry, limit your message to %d characters.\n", MAX_MSG_LEN);
		fflush(stdout);
	}
	else{//otherwise, send message to server
		outbuf[MAX_MSG_LEN] = 0;//null terminate the string
		send(client_socket, outbuf, strlen(outbuf), 0);//send the string to the server
		if (strcmp(outbuf, "bye") == 0){//if the program should end, print goodbye
			printf("Goodbye.\n");
			fflush(stdout);
			return 1;//returns a 1 for exit success
		}
	}
	return 0;//returns 0 to allow loop to continue
}

int handle_client_socket() {//handles messages from the server
	int numbytes = recv(client_socket, inbuf, BUFLEN -1, 0);//receives a message from another client from server, returns number of bytes
	if (numbytes < 0){//invalid number of bytes
		fprintf(stderr, "\nWarning: Failed to receive incoming message. %s.\n", strerror(errno));
		return 0;
	}
	inbuf[numbytes] = 0;//null terminates the string
	if (numbytes == 0){//if bytes are 0, error out
		fprintf(stderr, "\nConnection to server has been lost.\n");
		close(client_socket);
		exit(EXIT_FAILURE);//ends with failure because connection lost
	}
	else if (strcmp(inbuf, "bye") == 0){//if the server shuts down
		printf("\nServer initiated shutdown.\n");
		fflush(stdout);
		return 1;//ends program with success since server ends
	}
	else{//otherwise, print the message sent through server
		printf("\n%s\n", inbuf);
		fflush(stdout);
	}
	return 0;
}

int main(int argc, char *argv[]) {
	if (argc != 3){//checks for proper number of arguments, errors out if two args not supplied
		fprintf(stderr, "Usage: %s <server IP> <port>\n", argv[0]);
		exit(EXIT_FAILURE);
	}
	struct sockaddr_in sock;//creates a socket struct
	memset(&sock, 0, sizeof(sock));//zeroes out the struct
	sock.sin_family = AF_INET;//sets the type for IPv4
	int val = inet_pton(AF_INET, argv[1], &sock.sin_addr);//checks if the ip address is valid
	if (val != 1){//if the IP Address is invalid, error out
		fprintf(stderr,"Error: Invalid IP address '%s'.\n", argv[1]);
		exit(EXIT_FAILURE);
	}
	int portnum = 0;//int to store the port number
	if (parse_int(argv[2], &portnum, "port number") == false){//uses helper to check if the port number is a valid number, othwerise error out
		exit(EXIT_FAILURE);
	}
	if (portnum < 1024 || portnum > 65535){//checks that the port number is in the valid range, otherwise throw error
		fprintf(stderr, "Error: Port must be in range [1024, 65535].\n");
		exit(EXIT_FAILURE);
	}
	printf("Username: ");//prints out prompt for user to enter username
	fflush(stdout);
	int ustat;//int value for loop
	while((ustat = get_string(username, MAX_NAME_LEN + 1)) != OK){//loops until the user enters a valid username
		if (ustat == TOO_LONG){//if the username is too long, reprompt for another username
			printf("Sorry, limit your username to %d characters.\n", MAX_NAME_LEN);
		}
		printf("Username: ");
		fflush(stdout);
	}
	printf("Hello, %s. Let's try to connect to the server.\n", username);//prints out the saved username
	fflush(stdout);
	sock.sin_port = htons(portnum);//sets the port number
	sock.sin_addr.s_addr = inet_addr(argv[1]);//sets the IP address number
	client_socket = socket(AF_INET, SOCK_STREAM, 0);//creates a socket
	if (client_socket < 0){//checks that the socket was created properly
		fprintf(stderr, "Error: Failed to create socket. %s.\n", strerror(errno));
		exit(EXIT_FAILURE);
	}
	int connectr = connect(client_socket, (struct sockaddr*) &sock, sizeof(sock));//connects the socket
	if (connectr < 0){//if the connection fails, error out and close socket
		fprintf(stderr, "Error: Failed to connect to server. %s.\n", strerror(errno));
		close(client_socket);
		exit(EXIT_FAILURE);
	}
	int numbytes = recv(client_socket, inbuf, BUFLEN -1, 0);//receives message from the server
	if (numbytes < 0){//if the message is not received, error out and close socket
		fprintf(stderr, "Error: Failed to receive message from server. %s.\n", strerror(errno));
		close(client_socket);
		exit(EXIT_FAILURE);
	}
	else if (numbytes == 0){//if no connections are available, error out and close socket
		fprintf(stderr, "All connections are busy. Try again later. \n");
		close(client_socket);
		exit(EXIT_FAILURE);
	}
	inbuf[numbytes] = 0;//null terminates the input string
	printf("\n%s\n\n", inbuf);//outputs the message
	fflush(stdout);
	int sendv = send(client_socket, username, strlen(username), 0);//sends the username to the server
	if (sendv < 0){//if the username cannot be sent, error out and close socket
		fprintf(stderr, "Error: Failed to send username to server. %s.\n", strerror(errno));
		close(client_socket);
		exit(EXIT_FAILURE);
	}
	fd_set fds;//creates a set of file descriptors
	printf("[%s]: ", username);//prints out prompt
	fflush(stdout);//clears standard output
	while(1){
		FD_ZERO(&fds);//clears out the file descriptors
		FD_SET(client_socket, &fds);//adds the client socket to the set of fds
		FD_SET(STDIN_FILENO, &fds);//adds stdin to the set of fds
		if (select(client_socket+1, &fds, NULL, NULL, NULL) == -1){
			fprintf(stderr, "Error: Failed to receive input from server or user input.\n");
			close(client_socket);
			exit(EXIT_FAILURE);
		}
		int returnval = 0;//creates an int to store return value of helper functions
		if (FD_ISSET(STDIN_FILENO, &fds)){//handles stdin from the client
			returnval = handle_stdin();//calls helper function
			if (returnval == 1){//if a message is returned, exit with success
				close(client_socket);
				exit(EXIT_SUCCESS);
			}
		}
		if (FD_ISSET(client_socket, &fds)){//handles messages from the server
			returnval = handle_client_socket();//calls helper function
			if (returnval == 1){//if a message is returned, exit with success
				close(client_socket);
				exit(EXIT_SUCCESS);
			}
		}
		printf("[%s]: ", username);//prints out the standard input prompt
		fflush(stdout);
	}
	close(client_socket);//closes the socket if the program completes successfully
	return 0;
}
